import java.util.*;
import java.io.*;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Locale;
public class Karel {
    private int [][] array = new int[2][12];
    private String name = "";
    
    //consructer
    public Karel (String name){
        this.name = name;
        int ROW_LENGTH = array[0].length;
        for(int i = 0; i < ROW_LENGTH; i++){
            Month month = Month.of(i+1);
            String n = month.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
            Scanner input = new Scanner(System.in);
            System.out.print("Please input the cost value (don't add $) of electricity (rounded to the nearest dollar) for the month of " + n + ": ");
            
            int elec = input.nextInt();
            System.out.println();
            System.out.print("Please input the cost value (don't add $) of gas (rounded to the nearest dollar) for the month of " + n + ": ");
            int gas = input.nextInt();
            loadArray(i, elec, gas);
        }
    }
    //loads the array
    public void loadArray(int i, int elec, int gas){
        System.out.println();
        for (int a = 0; a < array.length; a++){
            if (a == 0){
                array[a][i] = elec;
            } else {
                array[a][i] = gas;
            }
        }
    }
        
    //traverses the array for data    
    public void printExpenses(){
        
        for (int a = 0; a < array.length; a++){
            if (a == 0){
                System.out.print("List of Electricity Expenenses: ");
            } else {
                System.out.println();
                System.out.print("List of Gas Expenses: ");
            }
            for (int i = 0; i < array[a].length; i++){
                if (i < 11){
                    System.out.print("$" + array[a][i] + ", ");    
                } else {
                    System.out.println("$" + array[a][i] + ".");
                }
                
            }
        }
        
        System.out.println();
        
        System.out.print("Approximate Total Electricity Expense: ");
        int electricity = 0;
        for (int i = 0; i < array[0].length; i++){
            electricity += array[0][i];
        }
        System.out.println("$" + electricity + ".");
        
        System.out.println();
        
        System.out.println("Approximate Total Gas Expenses: ");
        int gas = 0;
        for (int i = 0; i < array[1].length; i++){
            gas += array[1][i];
        }
        System.out.println("$" + gas + ".");
    }  
    
    
}