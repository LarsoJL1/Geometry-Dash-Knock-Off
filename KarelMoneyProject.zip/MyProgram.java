import java.util.*;
import java.io.*;
public class MyProgram
{
    public static void main(String[] args)
    {
        ArrayList <Karel> array = new ArrayList<Karel>();
        Boolean want = true;
        Scanner input = new Scanner(System.in);
        while (want){
            System.out.print("What do you want to name your Karel: ");
            String name = input.nextLine();
            System.out.println();
            Karel k = new Karel(name);
            k.printExpenses();
            array.add(k);
            System.out.println();
            System.out.println("Would you like to continue? (True = Yes/False = No)");
            want = input.nextBoolean();
            
        }
        
    }
}